rootProject.name = "gateway"
